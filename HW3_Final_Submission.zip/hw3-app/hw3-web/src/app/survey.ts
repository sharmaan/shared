/**
 * SWE-642 group : Anjali Sharma, Rachna Latkar, Bantwal Shreyas Mallya, Govind Sharma
 * domain class object passed with survey information to Rest API from service
 */
export class Survey {
  // id:number;
	  firstName:string;
	  lastName:string
	  streetAddr:string;
	  city:string;
	  state:string;
	  zip:string;
	  phone:string;
	  email:string;
	  dtSurvey:string;
	  mostLiked:string;
	  interestSource:string;
	  likelyToRecommend:string;
	  comments:string;
    // constructor(firstName:string,lastName:string,streetAddr:string,city:string,state:string,zip:string ,phone:string,email:string,dtSurvey:string,mostLiked:string,interestSource:string,likelyToRecommend:string,comments:string)
    //   {
    //     this.firstName=firstName;
    //     this.lastName=lastName;
    //     this.streetAddr=streetAddr;
    //     this.city=city;
    //     this.state=state;
    //     this.zip=zip;
    //     this.phone=phone;
    //     this.email=email;
    //     this.dtSurvey=dtSurvey;
    //     this.mostLiked=mostLiked;
    //     this.interestSource=interestSource;
    //     this.likelyToRecommend=likelyToRecommend;
    //     this.comments=comments;
    //   }
constructor(){}
}
