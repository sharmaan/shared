import { Component } from '@angular/core';
/**
 * SWE-642 group : Anjali Sharma, Rachna Latkar, Bantwal Shreyas Mallya, Govind Sharma
 * Default AppComponent gets generated when you create new Angular application using Angular CLI
 */
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'hw3-web';
}
