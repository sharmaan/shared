import { Survey } from './survey';

describe('Survey', () => {
  it('should create an instance', () => {
    expect(new Survey()).toBeTruthy();
  });
});
